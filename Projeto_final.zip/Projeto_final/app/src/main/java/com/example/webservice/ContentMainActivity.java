package com.example.webservice;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.DialogInterface;
import android.location.Geocoder;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.logging.Logger;


public class ContentMainActivity extends AppCompatActivity {
    private RecyclerView rvlista;
    private List<DBCep> listacep= new ArrayList<DBCep>();
    private DBCep cepselecionado;
    private CEPAdapter cepAdapter;
    RecyclerView.LayoutManager layoutManager;
    private TextView txtCepLB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_main);

        Listar();


        rvlista.addOnItemTouchListener(new RecyclerItemClickListener(getApplicationContext(), rvlista, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
            }

            @Override
            public void onLongItemClick(View view, int position) {
                cepselecionado = listacep.get(position);
                AlertDialog.Builder builder = new AlertDialog.Builder(ContentMainActivity.this);
                builder.setTitle("Confirmar exclusão");
                builder.setMessage("Deseja confirmar a exclusão do cep: " + cepselecionado.cep+"?");
                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        CEPDAO cepdao = new CEPDAO(getApplicationContext());
                        if (cepdao.deletar(cepselecionado)) {
                            carregarCep();
                            Toast.makeText(getApplicationContext(), "Cep excluido!", Toast.LENGTH_SHORT).show();
                        } else{
                            Toast.makeText(getApplicationContext(), "Erro ao excluir cep", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Não", null);
                builder.create().show();

            }

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        }));
    }

    public void Listar()
    {
        rvlista = findViewById(R.id.rvLista);

        List<DBCep> dbcep = new ArrayList<>();

        CEPDAO cepdao = new CEPDAO(getApplicationContext());

        //dbcep   = cepdao.listar();
        // dbcep.add(new DBCep("cep", "end", "comp", "brr", "loc", "es", 01L) );
        // dbcep.add(new DBCep("cep1", "end1", "comp1", "brr", "loc", "es", 02L) );

        CEPAdapter adapter = new CEPAdapter(cepdao.listar());

        rvlista.setHasFixedSize(true);
        rvlista.setLayoutManager(new LinearLayoutManager(this.getApplicationContext()));
        rvlista.setAdapter(adapter);
    }
    public void carregarCep(){
        CEPDAO cepdao = new CEPDAO(getApplicationContext());
        listacep =cepdao.listar();

        cepAdapter = new CEPAdapter(listacep);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        rvlista.setLayoutManager(layoutManager);
        rvlista.setHasFixedSize(true);
        rvlista.addItemDecoration(new DividerItemDecoration(getApplicationContext(), LinearLayout.VERTICAL));
        rvlista.setAdapter(cepAdapter);
    }

    @Override
    protected void onStart(){
        carregarCep();
        super.onStart();
    }
}